package com.example.finalprojectminigame;

import java.util.ArrayList;

public class BracketCommands {
   //these "bracket commands" will aide the player in finding the
    static ArrayList<String> bracketCommands = new ArrayList<>();

    static{
        bracketCommands.add("<>");
        bracketCommands.add("[./:#@!]");
        bracketCommands.add("{>}");
        bracketCommands.add("(,.#)");
        bracketCommands.add("<<;?#!@>");
        bracketCommands.add("(.$%&)");
    }
    static String resetTries = "<#/[:!>";
}
