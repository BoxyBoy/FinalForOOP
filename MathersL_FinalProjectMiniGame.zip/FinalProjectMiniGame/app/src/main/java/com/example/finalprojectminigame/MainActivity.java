package com.example.finalprojectminigame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static com.example.finalprojectminigame.BracketCommands.resetTries;
import static com.example.finalprojectminigame.Vocab.correctAnswer;
import static com.example.finalprojectminigame.Vocab.likeness;
import static com.example.finalprojectminigame.Vocab.wrongAnswers;
import static com.example.finalprojectminigame.BracketCommands.bracketCommands;

public class MainActivity extends AppCompatActivity {

    int guesses = 4;

    public TextView guessAmountView, terminalView, guessResultView, guessInput;

    public Button buttonCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        guessAmountView = findViewById(R.id.guessAmountView);
        terminalView = findViewById(R.id.terminalView);
        guessResultView = findViewById(R.id.guessResultView);
        guessInput = findViewById(R.id.guessInput);
        buttonCheck = findViewById(R.id.buttonCheck);

        // main textview is 20 characters wide and 18 strings tall
        terminalView.setText("[}',./!$#>//@^*@)(!&\n#..?#!&@(#@/;'[}" + bracketCommands.get(0) + "!@\n%&$#:!><./#}{" + wrongAnswers.get(0) + "-\n+#$!@%$#@" + wrongAnswers.get(1) + ")(!#\n!#&*@':|{]" + bracketCommands.get(1) + ",>\n/?'!^%==-#@" + bracketCommands.get(2) + "))(#$$\n@!-.<'" + wrongAnswers.get(2) + "!#@-]{|!\n" + correctAnswer + "$%#@!':.<+*&%$\n" + bracketCommands.get(3) + "!?$#%[}(" +bracketCommands.get(4) + "\n$#>,-=+!-+=" + wrongAnswers.get(3) + "(}]\n'$?;<!#%@%z^&*" + wrongAnswers.get(4) + "\n^&)($@!':}{#@" + bracketCommands.get(5) + ";\n===-#$(]!@" + resetTries + "?><\n:'$*&^@!" + wrongAnswers.get(5) + ",,.?//\n" + wrongAnswers.get(6) + "!@##$%--" + wrongAnswers.get(7) + "\n%%^$@*;:" + wrongAnswers.get(8) + "!^*^#@");
        // guess result view is 12 characters wide and 18 strings tall
        guessResultView.setText("");
    }

    public void onClickCheck(View v){
        String searchName = guessInput.getText().toString();
        if(wrongAnswers.contains(searchName.toUpperCase())) {
            guessResultView.append("\n>" + searchName.toUpperCase() + "\n>ACCESS DENIED\n>LIKENESS = " + likeness.get(wrongAnswers.indexOf(searchName.toUpperCase())) + "/6" );
            guesses--;
            String guessAmount = guesses + " attempt(s) left:";
            //guessAmountView.setText(guesses + " attempt(s) left:");
            for(int i = 0;i<guesses;i++){
                guessAmount += " []";
            }
            guessAmountView.setText(guessAmount);
            return;
        }
        else if(searchName.toUpperCase().equals(correctAnswer)){
            guessResultView.append("\n>" + searchName + "\n>ACCESS GRANTED!");
            buttonCheck.setEnabled(false);
            return;
        }
        String searchBracket = guessInput.getText().toString();
        if(bracketCommands.contains(searchBracket)){
            guessResultView.append("\n>" + searchBracket + "\n>REMOVED DUD");
            for(int i = 0;i<wrongAnswers.size();i++){
                if(wrongAnswers.get(i).equals("......")){
                    continue;
                }
                wrongAnswers.set(i, "......");
                break;
            }
            terminalView.setText("[}',./!$#>//@^*@)(!&\n#..?#!&@(#@/;'[}" + bracketCommands.get(0) + "!@\n%&$#:!><./#}{" + wrongAnswers.get(0) + "-\n+#$!@%$#@" + wrongAnswers.get(1) + ")(!#\n!#&*@':|{]" + bracketCommands.get(1) + ",>\n/?'!^%==-#@" + bracketCommands.get(2) + "))(#$$\n@!-.<'" + wrongAnswers.get(2) + "!#@-]{|!\n" + correctAnswer + "$%#@!':.<+*&%$\n" + bracketCommands.get(3) + "!?$#%[}(" +bracketCommands.get(4) + "\n$#>,-=+!-+=" + wrongAnswers.get(3) + "(}]\n'$?;<!#%@%z^&*" + wrongAnswers.get(4) + "\n^&)($@!':}{#@" + bracketCommands.get(5) + ";\n===-#$(]!@" + resetTries + "?><\n:'$*&^@!" + wrongAnswers.get(5) + ",,.?//\n" + wrongAnswers.get(6) + "!@##$%--" + wrongAnswers.get(7) + "\n%%^$@*;:" + wrongAnswers.get(8) + "!^*^#@");
            return;
        }
        else if(searchBracket.equals(BracketCommands.resetTries)){
            guessResultView.append("\n>ATTEMPTS RESET");
            //reset tries on text view and in code
            guesses = 4;
            guessAmountView.setText(guesses + " attempt(s) left: [] [] [] []");
            return;
        }
        guessResultView.append("\n>" + searchName + "\n>ERROR");
    }
}