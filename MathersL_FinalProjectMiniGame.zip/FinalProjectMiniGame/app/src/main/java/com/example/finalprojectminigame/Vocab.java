package com.example.finalprojectminigame;

import java.util.ArrayList;

public class Vocab {
    // list of worng answers for the game. Allows me to organize all of my strings and will cut down on the coding in the main activity
    static ArrayList<String> wrongAnswers = new ArrayList<>();

    static {
        wrongAnswers.add("RADISH");
        wrongAnswers.add("NUMBER");
        wrongAnswers.add("STRING");
        wrongAnswers.add("PENCIL");
        wrongAnswers.add("KAILEE");
        wrongAnswers.add("BARKER");
        wrongAnswers.add("CREATE");
        wrongAnswers.add("TURKEY");
        wrongAnswers.add("JALOPS");
    }
    static String correctAnswer = "SLAPPY";

    static ArrayList<Integer> likeness = new ArrayList<>();

    static{
        likeness.add(2);
        likeness.add(0);
        likeness.add(1);
        likeness.add(2);
        likeness.add(2);
        likeness.add(1);
        likeness.add(1);
        likeness.add(1);
        likeness.add(3);
    }
}